<?php
declare(strict_types=1);
require __DIR__.'/app/bootstrap.php';
$lock=__DIR__.'/app/installed.lock';
if(is_file($lock)){http_response_code(403);exit('راه‌اندازی قبلاً انجام شده است. این فایل را حذف نکنید؛ برای امنیت آن را از هاست پاک کنید.');}
$error='';$done=false;
if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf();
 $username=trim((string)($_POST['username']??''));$password=(string)($_POST['password']??'');$confirm=(string)($_POST['confirm']??'');
 if(!preg_match('/^[a-zA-Z0-9_.-]{4,50}$/',$username))$error='نام کاربری باید حداقل ۴ حرف انگلیسی یا عدد باشد.';
 elseif(strlen($password)<12)$error='رمز عبور باید حداقل ۱۲ کاراکتر باشد.';
 elseif($password!==$confirm)$error='تکرار رمز عبور مطابقت ندارد.';
 else {
  try {
   $pdo=db();
   $sql=file_get_contents(__DIR__.'/database/schema.sql');
   foreach(array_filter(array_map('trim',explode(';',$sql))) as $statement){if($statement!=='')$pdo->exec($statement);}
   $st=$pdo->prepare('INSERT INTO admins (username,password_hash,created_at) VALUES (?,?,NOW())');$st->execute([$username,password_hash($password,PASSWORD_DEFAULT)]);
   $pdo->exec("INSERT IGNORE INTO settings (setting_key,setting_value) VALUES ('site_name','Design Nest')");
   $pdo->exec("INSERT INTO reviews (customer_name,service,rating,review_text,is_approved,is_demo,created_at) VALUES ('مشتری نمونه ۱','هویت بصری',5,'نمونه نمایشی برای نمایش ظاهر بخش دیدگاه‌ها؛ نظر واقعی مشتری نیست.',1,1,NOW()),('مشتری نمونه ۲','طراحی شبکه‌های اجتماعی',5,'این متن صرفاً محتوای آزمایشی است و پس از دریافت نظر واقعی جایگزین می‌شود.',1,1,NOW())");
   file_put_contents($lock,'installed '.date(DATE_ATOM));@chmod($lock,0600);$done=true;
  }catch(Throwable $e){error_log('Nestgrafic setup: '.$e->getMessage());$error='راه‌اندازی ناموفق بود. تنظیمات دیتابیس و مجوزهای پوشه app را بررسی کنید.';}
 }
}
?><!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>راه‌اندازی Nestgrafic</title><link rel="stylesheet" href="/assets/css/style.css"></head><body class="simple-page"><main class="login-card"><div class="eyebrow">FIRST-TIME SETUP</div><h1>راه‌اندازی <em>مدیریت</em></h1><?php if($done):?><div class="alert success">راه‌اندازی انجام شد. حالا این فایل setup.php را از هاست حذف کنید و وارد پنل شوید.</div><a class="btn btn-primary" href="/admin/login.php">ورود به پنل</a><?php else:?><?php if($error):?><div class="alert error"><?=e($error)?></div><?php endif?><p>این صفحه را فقط یک بار، پس از تنظیم دیتابیس، اجرا کنید. رمز قوی و یکتا انتخاب کنید.</p><form method="post"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><label>نام کاربری مدیر<input name="username" required minlength="4"></label><label>رمز عبور مدیر<input type="password" name="password" required minlength="12"></label><label>تکرار رمز عبور<input type="password" name="confirm" required minlength="12"></label><button class="btn btn-primary full">ساخت پنل مدیریت</button></form><?php endif?></main></body></html>
