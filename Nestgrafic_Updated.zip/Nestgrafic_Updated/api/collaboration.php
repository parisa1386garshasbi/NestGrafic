<?php
declare(strict_types=1);
require __DIR__.'/../app/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit('Method not allowed'); }
verify_csrf();
$name=trim((string)($_POST['name']??'')); $phone=trim((string)($_POST['phone']??'')); $specialty=trim((string)($_POST['specialty']??'')); $portfolio=trim((string)($_POST['portfolio']??''));
if ($name==='' || !preg_match('/^[+0-9۰-۹\s()\-]{8,30}$/u',$phone) || $specialty==='') { http_response_code(422); exit('لطفاً نام، شماره تماس و حوزه تخصصی را درست وارد کنید.'); }
try {
 $st=db()->prepare('INSERT INTO collaborations (name,phone,specialty,portfolio,status,created_at) VALUES (?,?,?,?,?,NOW())');
 $st->execute([mb_substr($name,0,120),mb_substr($phone,0,30),mb_substr($specialty,0,150),mb_substr($portfolio,0,1500),'new']);
 redirect('/collaboration-success.php');
} catch(Throwable $e) { error_log('Nestgrafic collaboration error: '.$e->getMessage()); http_response_code(500); exit('ثبت درخواست انجام نشد؛ تنظیمات پایگاه داده را بررسی کنید.'); }
