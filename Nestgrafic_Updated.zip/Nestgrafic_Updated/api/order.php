<?php
declare(strict_types=1);
require __DIR__.'/../app/bootstrap.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit('Method not allowed'); }
verify_csrf();
function val(string $k,int $max=3000): string { $v=trim((string)($_POST[$k]??'')); return mb_substr($v,0,$max,'UTF-8'); }
$name=val('customer_name',120); $phone=val('phone',30); $email=val('email',190); $service=val('service',180); $details=val('details',3000);
$contact=val('contact_preference',30); $budget=val('budget',80); $deadline=val('deadline',80); $format=val('delivery_format',100); $reference=val('reference_link',500);
if ($name==='' || !preg_match('/^[+0-9۰-۹\s()\-]{8,30}$/u',$phone) || $service==='' || empty($_POST['terms']) || ($email!=='' && !filter_var($email,FILTER_VALIDATE_EMAIL)) || ($reference!=='' && !filter_var($reference,FILTER_VALIDATE_URL))) { http_response_code(422); exit('اطلاعات واردشده کامل یا معتبر نیست. به صفحه قبل برگردید و فرم را بررسی کنید.'); }
$attachment=null;
if (!empty($_FILES['attachment']['name'])) {
 $f=$_FILES['attachment']; $allowed=['pdf'=>'application/pdf','png'=>'image/png','jpg'=>'image/jpeg','jpeg'=>'image/jpeg','webp'=>'image/webp','zip'=>'application/zip'];
 $ext=strtolower(pathinfo($f['name'],PATHINFO_EXTENSION));
 if (($f['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK || $f['size']>8*1024*1024 || !isset($allowed[$ext])) { http_response_code(422); exit('فایل پیوست باید PDF، تصویر یا ZIP و حداکثر ۸ مگابایت باشد.'); }
 $finfo=new finfo(FILEINFO_MIME_TYPE); $mime=$finfo->file($f['tmp_name']);
 if (!in_array($mime,array_values($allowed),true)) { http_response_code(422); exit('نوع فایل قابل قبول نیست.'); }
 $dir=dirname(__DIR__).'/storage/uploads'; if (!is_dir($dir) && !mkdir($dir,0750,true)) { http_response_code(500); exit('ساخت پوشهٔ فایل‌ها ناموفق بود.'); }
 $filename=bin2hex(random_bytes(16)).'.'.$ext; if (!move_uploaded_file($f['tmp_name'],$dir.'/'.$filename)) { http_response_code(500); exit('ذخیرهٔ فایل ناموفق بود.'); }
 $attachment='storage/uploads/'.$filename;
}
try {
 $code='DN-'.strtoupper(bin2hex(random_bytes(4)));
 $st=db()->prepare('INSERT INTO orders (tracking_code,customer_name,phone,email,contact_preference,service,details,budget,deadline,delivery_format,reference_link,attachment_path,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),NOW())');
 $st->execute([$code,$name,$phone,$email?:null,$contact?:'phone',$service,$details,$budget?:null,$deadline?:null,$format?:null,$reference?:null,$attachment,'received']);
 $_SESSION['last_tracking_code']=$code; redirect('/order-success.php');
} catch(Throwable $e) { error_log('Nestgrafic order error: '.$e->getMessage()); http_response_code(500); exit('ثبت سفارش فعلاً انجام نشد. تنظیمات پایگاه داده را بررسی کنید یا بعداً دوباره تلاش کنید.'); }
