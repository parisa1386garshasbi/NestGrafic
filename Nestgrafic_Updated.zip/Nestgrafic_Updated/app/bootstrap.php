<?php
declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name('nestgrafic_session');
    session_start(['cookie_httponly'=>true,'cookie_samesite'=>'Lax','use_strict_mode'=>true]);
}
$configFile = __DIR__ . '/config.php';
$config = is_file($configFile) ? require $configFile : [];

// Base path supports both the live domain root and a local MAMP subfolder.
$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
if (preg_match('~/(admin|api)$~', $scriptDir)) {
    $scriptDir = dirname($scriptDir);
}
$baseUrl = ($scriptDir === '/' || $scriptDir === '.' ? '' : rtrim($scriptDir, '/'));

function e(?string $v): string { return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function db(): PDO {
    static $pdo = null;
    global $config;
    if ($pdo instanceof PDO) return $pdo;
    if (empty($config['db']['host']) || empty($config['db']['name']) || empty($config['db']['user'])) {
        throw new RuntimeException('تنظیمات پایگاه داده کامل نیست. فایل app/config.php را تنظیم کنید.');
    }
    $dsn = 'mysql:host='.$config['db']['host'].';dbname='.$config['db']['name'].';charset=utf8mb4';
    $pdo = new PDO($dsn, $config['db']['user'], (string)$config['db']['pass'], [
        PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES=>false,
    ]);
    return $pdo;
}
function service_catalog(): array {
 return ['لوگو و هویت بصری','برندبوک و هویت سازمانی','طراحی اقلام چاپی','طراحی بسته‌بندی و لیبل','طراحی شبکه‌های اجتماعی','طراحی سایت و UI/UX','تصویرسازی دیجیتال','ویرایش و رتوش عکس','صفحه‌آرایی و طراحی PDF','طراحی لباس و پترن','موشن‌گرافیک و انیمیشن','پرزنتیشن و Pitch Deck','طراحی و چاپ (پکیج ترکیبی)','مشاوره / سایر'];
}
function redirect(string $path): never { header('Location: '.$path); exit; }
function csrf_token(): string { if (empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function verify_csrf(): void {
 $token=(string)($_POST['csrf']??'');
 if (!$token || !hash_equals((string)($_SESSION['csrf']??''),$token)) { http_response_code(419); exit('درخواست منقضی شده است. صفحه را تازه‌سازی کنید.'); }
}
function flash(string $key, ?string $value=null): ?string {
 if ($value !== null) { $_SESSION['_flash'][$key]=$value; return null; }
 $v=$_SESSION['_flash'][$key]??null; unset($_SESSION['_flash'][$key]); return $v;
}
function admin_required(): void { if (empty($_SESSION['admin_id'])) redirect('/admin/login.php'); }
function app_setting(string $key, string $default=''): string {
 try { $st=db()->prepare('SELECT setting_value FROM settings WHERE setting_key=?'); $st->execute([$key]); $v=$st->fetchColumn(); return $v===false?$default:(string)$v; } catch(Throwable $e) { return $default; }
}
