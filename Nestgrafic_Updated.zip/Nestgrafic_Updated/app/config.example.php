<?php
/* Copy this file to app/config.php and fill in your hosting/database details.
   Never upload real passwords to public repositories. */
return [
 'site_name' => 'Design Nest',
 'base_url' => 'https://nestgrafic.com',
 'db' => [
   'host' => 'localhost',
   'name' => 'CPANEL_DATABASE_NAME',
   'user' => 'CPANEL_DATABASE_USER',
   'pass' => 'CHANGE_TO_A_LONG_PASSWORD',
 ],
 'timezone' => 'Asia/Tehran',
 'payment' => [
   'provider' => 'zarinpal',
   'merchant_id' => 'PUT_OFFICIAL_MERCHANT_ID_HERE',
   'sandbox' => true,
   'currency' => 'IRR',
 ],
];
