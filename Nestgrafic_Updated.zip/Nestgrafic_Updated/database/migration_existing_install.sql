-- Run ONLY if this database already has the original Nestgrafic PHP schema installed.
ALTER TABLE orders ADD COLUMN contact_preference VARCHAR(30) NULL AFTER email;
ALTER TABLE orders ADD COLUMN budget VARCHAR(80) NULL AFTER details;
ALTER TABLE orders ADD COLUMN deadline VARCHAR(80) NULL AFTER budget;
ALTER TABLE orders ADD COLUMN delivery_format VARCHAR(100) NULL AFTER deadline;
ALTER TABLE orders ADD COLUMN reference_link VARCHAR(500) NULL AFTER delivery_format;
ALTER TABLE orders ADD COLUMN attachment_path VARCHAR(255) NULL AFTER reference_link;
ALTER TABLE orders ADD COLUMN payment_status VARCHAR(30) NOT NULL DEFAULT 'unpaid' AFTER status;
ALTER TABLE orders ADD COLUMN agreed_amount DECIMAL(12,2) NULL AFTER payment_status;
ALTER TABLE orders ADD COLUMN currency VARCHAR(8) NOT NULL DEFAULT 'IRR' AFTER agreed_amount;
CREATE TABLE IF NOT EXISTS reviews (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 customer_name VARCHAR(120) NOT NULL,
 service VARCHAR(180) NOT NULL,
 rating TINYINT UNSIGNED NOT NULL DEFAULT 5,
 review_text TEXT NOT NULL,
 is_approved TINYINT(1) NOT NULL DEFAULT 0,
 is_demo TINYINT(1) NOT NULL DEFAULT 0,
 created_at DATETIME NOT NULL,
 INDEX idx_reviews_public (is_approved,is_demo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO reviews (customer_name,service,rating,review_text,is_approved,is_demo,created_at) VALUES
('مشتری نمونه ۱','هویت بصری',5,'نمونه نمایشی برای نمایش ظاهر بخش دیدگاه‌ها؛ نظر واقعی مشتری نیست.',1,1,NOW()),
('مشتری نمونه ۲','طراحی شبکه‌های اجتماعی',5,'این متن صرفاً محتوای آزمایشی است و پس از دریافت نظر واقعی جایگزین می‌شود.',1,1,NOW());

CREATE TABLE IF NOT EXISTS payments (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, order_id BIGINT UNSIGNED NOT NULL,
 provider VARCHAR(40) NOT NULL DEFAULT 'zarinpal', amount DECIMAL(12,2) NOT NULL,
 currency VARCHAR(8) NOT NULL DEFAULT 'IRR', authority VARCHAR(120) NULL UNIQUE, ref_id VARCHAR(120) NULL,
 status VARCHAR(30) NOT NULL DEFAULT 'created', request_payload JSON NULL, verify_payload JSON NULL,
 created_at DATETIME NOT NULL, paid_at DATETIME NULL, INDEX idx_payments_order (order_id), INDEX idx_payments_status (status),
 CONSTRAINT fk_payments_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
