document.addEventListener('DOMContentLoaded',()=>{
 document.querySelectorAll('[data-service]').forEach(el=>el.addEventListener('click',()=>{
  const select=document.getElementById('service-select'); if(!select)return;
  const wanted=el.dataset.service||'';
  const option=[...select.options].find(o=>o.text.includes(wanted)||wanted.includes(o.text));
  if(option)select.value=option.value;
 }));
 document.querySelectorAll('form[action^="/api/"]').forEach(form=>form.addEventListener('submit',()=>{
  const btn=form.querySelector('button[type="submit"]');if(btn){btn.disabled=true;btn.dataset.original=btn.innerHTML;btn.innerHTML='در حال ارسال…';}
 }));
});
